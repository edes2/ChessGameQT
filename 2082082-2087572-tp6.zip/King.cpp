#include "King.hpp"

int Modele::King::compteur = 0;

Modele::King::King()
{
	if (compteur >= 2)
	{
		throw MoreThanTwoKings();
	}
	++compteur;
}

Modele::King::~King()
{
	--compteur;
}

//std::vector<Coordonnees> King::attaquesPossibles(std::map<Coordonnees, std::shared_ptr<ChessPiece>> tiles)
//{
//	std::vector<Coordonnees> attaques;
//
//	return attaques;
//}
//
//std::vector<Coordonnees> King::movementsPossibles(std::map<Coordonnees, std::shared_ptr<ChessPiece>> tiles)
//{
//	std::vector<Coordonnees> x;
//	return x;
//}

bool Modele::King::estMovementValide(Coordonnees destination, std::map<Coordonnees, std::shared_ptr<ChessPiece>> tiles)
{
	return false;
}
bool Modele::King::estAttaqueValide(Coordonnees destination, std::map<Coordonnees, std::shared_ptr<ChessPiece>> tiles)
{
	return false;
}

QString Modele::King::getImagePath() {
	QString path;
	if (side_ == white) {
		path = "50px/WhiteKing.png";
	}
	else
	{
		path = "50px/BlackKing.png";
	}
	return path;
}