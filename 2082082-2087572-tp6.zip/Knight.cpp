#include "Knight.hpp"


bool Modele::Knight::estMovementValide(Coordonnees destination, std::map<Coordonnees, std::shared_ptr<ChessPiece>> tiles)
{
	return false;
}
bool Modele::Knight::estAttaqueValide(Coordonnees destination, std::map<Coordonnees, std::shared_ptr<ChessPiece>> tiles)
{
	return false;
}

QString Modele::Knight::getImagePath() {
	QString path;
	if (side_ == white) {
		path = "50px/WhiteKnight.png";
	}
	else
	{
		path = "50px/BlackKnight.png";
	}
	return path;
}