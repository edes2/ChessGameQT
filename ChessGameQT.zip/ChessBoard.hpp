#pragma once

#include "namespace.hpp"
#include "Coordonnees.hpp"
#include "ChessPiece.hpp"
#pragma warning(push, 0) // Sinon Qt fait des avertissements � /W4.
#include <QObject>
#include <map>
#pragma pop()

class ChessBoard : public QObject {
	Q_OBJECT
public:
	ChessBoard() = default;
	void initPartie();
	std::map<Coordonnees, std::shared_ptr<ChessPiece>> tiles;
	side getTurn();
	void switchTurn();
public slots: // Lorsque recoit changements de la vue.
	void caseAppuye(Coordonnees position);
signals: // Pour envoyer un signal lorsque le modele a change une valeur
	void pieceDeplacee();
private:
	bool tryMove(Coordonnees destination);
	bool estEnEchec();
	void estEnEchecEtMath();
	std::shared_ptr<Coordonnees> caseSelectionnee;
	std::shared_ptr<ChessPiece> whiteKing;
	std::shared_ptr<ChessPiece> blackKing;
	side turn_;
	bool gagnantPartie;
};
