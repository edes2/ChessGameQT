#include "ChessPiece.hpp"

void Modele::ChessPiece::setSide(side side)
{
	side_ = side;
}

side Modele::ChessPiece::getSide()
{
	return side_;
}

void Modele::ChessPiece::updatePos(Coordonnees position)
{
	position_ = position;
}